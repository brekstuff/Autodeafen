# Auto Deafen

Auto Deafen watches Geometry Dash's native level percentage and shows a reminder at a configurable progress threshold. It supports an optional delay, an end-of-attempt reminder, and an opt-in practice mode.

Discord does not currently provide this mod with an approved way to change an ordinary desktop voice session's deafen state while guaranteeing the microphone is not muted. The mod uses no Discord credentials and never sends Discord controls.
