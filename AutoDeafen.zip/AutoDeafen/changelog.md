## v1.0.0

- Initial Windows Geode release for Geometry Dash 2.2081.
- Added progress threshold, delay, practice-mode option, and attempt-end reminder.
- Uses the game's native progress percentage and never reads or stores Discord credentials.
