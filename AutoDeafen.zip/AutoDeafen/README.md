# Auto Deafen

Auto Deafen is a Windows Geode mod for Geometry Dash 2.2081. It reads Geometry Dash's own `PlayLayer::getCurrentPercent()` value and shows a one-time in-game reminder when the selected threshold is reached.

## Discord limitation

The reminder is the safest supported behavior available for an ordinary Discord desktop voice session. Discord's current Social SDK exposes desktop voice settings through RPC as a read-only snapshot. Its writable `SetSelfDeaf` controls apply to calls managed by an approved Social SDK integration, not the user's ordinary Discord desktop voice connection. Discord's documented deafen keyboard shortcut can also mute the microphone. This mod therefore does not send synthetic keypresses, call undocumented endpoints, or read/store Discord credentials.

At the threshold, use Discord's own controls if you want to deafen manually. If **Undeafen on Attempt End** is enabled, the mod reminds you at the end of the run to toggle deafen off if you enabled it manually.

Official references:

- [Discord Social SDK release notes](https://discord.com/developers/docs/social-sdk/release_notes.html) (1.10.19337, September 1, 2026: desktop voice settings added as read-only RPC access)
- [Discord Social SDK `Client`](https://discord.com/developers/docs/social-sdk/classdiscordpp_1_1Client.html) (`GetVoiceSettings` is read-only; `SetSelfDeafAll` applies to the SDK's active calls)
- [Discord Social SDK `Call`](https://discord.com/developers/docs/social-sdk/classdiscordpp_1_1Call.html) (`SetSelfDeaf` controls the current SDK-managed call)
- [Discord keyboard shortcuts](https://support.discord.com/hc/en-us/articles/31232432266647-Discord-Commands-Shortcuts-and-Navigation-Guide) (Windows deafen shortcut and custom keybinds)

## Settings

Open **Geode > Mods > Auto Deafen > Settings** in Geometry Dash. The **Auto Deafen** section contains:

- **Auto Deafen**: enables or disables the threshold reminder.
- **Trigger Percentage (%)**: slider from 0 to 100. The selected value is shown with the slider. A value of 0 triggers as soon as gameplay becomes active.
- **Undeafen on Attempt End**: shows an end reminder after the threshold reminder has fired.
- **Delay After Trigger (ms)**: optional delay from 0 to 2000 ms, in 50 ms steps.
- **Include Practice Mode**: off by default. When enabled, progress can trigger once for the practice run. Practice deaths/checkpoint restores do not re-arm it; a full restart does.

The threshold is sampled every 30 ms while the level is actively playing. The mod does not estimate progress from elapsed time. A death or level completion ends a normal attempt; practice checkpoint deaths do not end the practice run. Exiting the level always ends the run.

## Build on Windows

### Prerequisites

- Geometry Dash for Windows, version 2.2081
- Geode for Windows, with its current stable developer SDK
- Geode CLI
- CMake 3.25 or newer
- A C++23-capable Windows compiler and build tools (the Geode Windows SDK toolchain installed by the CLI is recommended)

Install the Geode CLI using the official Windows instructions. With WinGet:

```powershell
winget install GeodeSDK.GeodeCLI
```

Then install the current stable Geode SDK and Windows binaries:

```powershell
geode sdk install
geode sdk install-binaries
```

Close and reopen PowerShell after installation so the `GEODE_SDK` environment variable is available. From the project folder, build with:

```powershell
geode build
```

If no Geode game profile is configured for automatic installation, the packaged file will be generated at:

```text
build\autodeafen.auto-deafen.geode
```

Install that `.geode` file through Geode's in-game mod installer, or copy it into the Geometry Dash Geode mods folder. For the default Steam installation, the folder is:

```text
C:\Program Files (x86)\Steam\steamapps\common\Geometry Dash\geode\mods\
```

Geode may install the built mod automatically when a CLI profile is configured.

## Project layout

```text
AutoDeafen/
├── CMakeLists.txt
├── README.md
├── about.md
├── changelog.md
├── mod.json
├── support.md
└── src/
    └── main.cpp
```

This project targets the currently released Geode SDK `v5.10.1` and Geometry Dash `2.2081` on Windows. Update the manifest and SDK together when the Geode or game version changes.
