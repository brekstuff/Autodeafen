#include <Geode/Geode.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/ui/Notification.hpp>

#include <algorithm>
#include <cstdint>
#include <string>

using namespace geode::prelude;

namespace {
    constexpr float kProgressPollInterval = 0.03f;

    struct AttemptState {
        bool reminderQueued = false;
        bool reminderShown = false;
        bool endReminderShown = false;
        bool endReminderPending = false;
        float pollElapsed = 0.f;
        float delayRemaining = 0.f;
    };

    AttemptState g_attempt;
    bool g_fullRestartRequested = false;

    bool isEnabled() {
        return Mod::get()->getSettingValue<bool>("auto-deafen-enabled");
    }

    bool includePracticeMode() {
        return Mod::get()->getSettingValue<bool>("include-practice-mode");
    }

    void showNotification(std::string const& message) {
        if (auto notification = Notification::create(message, NotificationIcon::Info, 4.f)) {
            notification->show();
        }
    }

    void resetAttemptState() {
        g_attempt = {};
    }

    void showAttemptEndReminder() {
        g_attempt.endReminderPending = false;
        showNotification(
            "Auto Deafen: attempt ended. If you deafened manually, toggle Discord deafen off."
        );
    }

    void finishAttempt(bool preserveQueuedReminder = false) {
        if (!preserveQueuedReminder) {
            g_attempt.reminderQueued = false;
        }
        if (g_attempt.endReminderShown) {
            return;
        }

        g_attempt.endReminderShown = true;
        if (!g_attempt.reminderShown ||
            !Mod::get()->getSettingValue<bool>("undeafen-on-attempt-end")) {
            if (preserveQueuedReminder && g_attempt.reminderQueued &&
                Mod::get()->getSettingValue<bool>("undeafen-on-attempt-end")) {
                g_attempt.endReminderPending = true;
            }
            return;
        }

        showAttemptEndReminder();
    }

    void showThresholdReminder() {
        g_attempt.reminderQueued = false;
        if (g_attempt.reminderShown) {
            return;
        }

        g_attempt.reminderShown = true;
        auto const percentage = std::clamp<int64_t>(
            Mod::get()->getSettingValue<int64_t>("trigger-percentage"), 0, 100
        );

        showNotification(fmt::format(
            "Auto Deafen: reached {}%. Use Discord's own deafen control if desired.",
            percentage
        ));

        if (g_attempt.endReminderPending) {
            showAttemptEndReminder();
        }
    }
}

class $modify(AutoDeafenPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        resetAttemptState();
        g_fullRestartRequested = false;
        return PlayLayer::init(level, useReplay, dontCreateObjects);
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);

        if (!isEnabled() || !this->isGameplayActive() || this->m_playerDied ||
            this->m_hasCompletedLevel ||
            (this->m_isPracticeMode && !includePracticeMode()) ||
            g_attempt.reminderShown) {
            return;
        }

        if (g_attempt.reminderQueued) {
            g_attempt.delayRemaining -= dt;
            if (g_attempt.delayRemaining <= 0.f) {
                showThresholdReminder();
            }
            return;
        }

        g_attempt.pollElapsed += dt;
        if (g_attempt.pollElapsed < kProgressPollInterval) {
            return;
        }
        g_attempt.pollElapsed = 0.f;

        auto const threshold = static_cast<float>(std::clamp<int64_t>(
            Mod::get()->getSettingValue<int64_t>("trigger-percentage"), 0, 100
        ));

        // Use Geometry Dash's own level percentage. The short poll interval avoids
        // doing percentage work on every frame while still catching threshold crossings.
        if (this->getCurrentPercent() < threshold) {
            return;
        }

        g_attempt.reminderQueued = true;
        auto const delayMs = std::clamp<int64_t>(
            Mod::get()->getSettingValue<int64_t>("delay-after-trigger-ms"), 0, 2000
        );
        g_attempt.delayRemaining = static_cast<float>(delayMs) / 1000.f;

        if (g_attempt.delayRemaining <= 0.f) {
            showThresholdReminder();
        }
    }

    void onThresholdDelayElapsed(float) {
        if (g_attempt.reminderQueued) {
            showThresholdReminder();
        }
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) {
        PlayLayer::destroyPlayer(player, object);

        if (!this->m_isPracticeMode &&
            (player == this->m_player1 || player == this->m_player2)) {
            finishAttempt();
        }
    }

    void resetLevel() {
        PlayLayer::resetLevel();

        // Normal mode starts a new attempt on reset. In practice mode, deaths restore
        // checkpoints and remain part of the same run; a full/manual restart resets it.
        if (!this->m_isPracticeMode || g_fullRestartRequested) {
            resetAttemptState();
        }
        g_fullRestartRequested = false;
    }

    void resetLevelFromStart() {
        PlayLayer::resetLevelFromStart();
        resetAttemptState();
        g_fullRestartRequested = false;
    }

    void levelComplete() {
        // The final percentage can be reached on the same update that completes
        // the level, after postUpdate's normal sampling point. Check it explicitly.
        if (!g_attempt.reminderShown && !g_attempt.reminderQueued && isEnabled() &&
            (!this->m_isPracticeMode || includePracticeMode())) {
            auto const threshold = static_cast<float>(std::clamp<int64_t>(
                Mod::get()->getSettingValue<int64_t>("trigger-percentage"), 0, 100
            ));
            if (this->getCurrentPercent() >= threshold) {
                auto const delayMs = std::clamp<int64_t>(
                    Mod::get()->getSettingValue<int64_t>("delay-after-trigger-ms"), 0, 2000
                );
                g_attempt.reminderQueued = true;
                g_attempt.delayRemaining = static_cast<float>(delayMs) / 1000.f;
                if (delayMs <= 0) {
                    showThresholdReminder();
                } else {
                    this->scheduleOnce(
                        schedule_selector(AutoDeafenPlayLayer::onThresholdDelayElapsed),
                        g_attempt.delayRemaining
                    );
                }
            }
        } else if (g_attempt.reminderQueued) {
            // A queued reminder stops receiving postUpdate ticks at completion.
            this->scheduleOnce(
                schedule_selector(AutoDeafenPlayLayer::onThresholdDelayElapsed),
                std::max(g_attempt.delayRemaining, 0.f)
            );
        }

        finishAttempt(true);
        PlayLayer::levelComplete();
    }

    void onQuit() {
        finishAttempt();
        PlayLayer::onQuit();
    }
};

class $modify(AutoDeafenPauseLayer, PauseLayer) {
    void onRestart(CCObject* sender) {
        finishAttempt();
        g_fullRestartRequested = true;
        PauseLayer::onRestart(sender);
    }

    void onRestartFull(CCObject* sender) {
        finishAttempt();
        g_fullRestartRequested = true;
        PauseLayer::onRestartFull(sender);
    }
};
